/*
 * I2C_config.h
 *
 *  Created on: Aug 11, 2024
 *      Author: Elmag
 */

#ifndef MCAL_I2C_I2C_CONFIG_H_
#define MCAL_I2C_I2C_CONFIG_H_

#define I2C_SLAVE_ADRESS 0x12

#endif /* MCAL_I2C_I2C_CONFIG_H_ */
