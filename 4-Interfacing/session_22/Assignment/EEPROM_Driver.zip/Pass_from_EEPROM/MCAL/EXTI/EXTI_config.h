/*
 * EXTI_config.h
 *
 *  Created on: Jul 30, 2024
 *      Author: Mohammed Mansour
 */

#ifndef MCAL_EXTI_EXTI_CONFIG_H_
#define MCAL_EXTI_EXTI_CONFIG_H_

/*
#define  EXTI_RISING	0
#define  EXTI_FALLING	1
#define  EXTI_ONCHANGE	2
#define  EXTI_LOWLEVEL	3


#define EXTI0_MODE	EXTI_FALLING
#define EXTI1_MODE	EXTI_FALLING
#define EXTI2_MODE	EXTI_RISING		// Only Rising or Falling
*/
#endif /* MCAL_EXTI_EXTI_CONFIG_H_ */
