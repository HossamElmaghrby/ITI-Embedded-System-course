/*
 * DIO_config.h
 *
 *  Created on: Jul 25, 2024
 *      Author: Mohammed Mansour
 */

#ifndef MCAL_DIO_DIO_CONFIG_H_
#define MCAL_DIO_DIO_CONFIG_H_



#endif /* MCAL_DIO_DIO_CONFIG_H_ */
