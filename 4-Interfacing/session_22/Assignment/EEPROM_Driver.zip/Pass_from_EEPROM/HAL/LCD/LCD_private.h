/*
 * LCD_private.h
 *
 *  Created on: Jul 29, 2024
 *      Author: Elmag
 */

#ifndef LCD_LCD_PRIVATE_H_
#define LCD_LCD_PRIVATE_H_

void static HLCD_voidSendPulse(void);

#endif /* LCD_LCD_PRIVATE_H_ */
