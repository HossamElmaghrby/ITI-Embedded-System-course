/*
 * Motor_private.h
 *
 *  Created on: Jul 31, 2024
 *      Author: Mohammed Mansour
 */

#ifndef MOTOR_MOTOR_PRIVATE_H_
#define MOTOR_MOTOR_PRIVATE_H_



#endif /* MOTOR_MOTOR_PRIVATE_H_ */
