/*
 * ICU_config.h
 *
 *  Created on: Aug 6, 2024
 *      Author: Mohammed Mansour
 */

#ifndef ICU_ICU_CONFIG_H_
#define ICU_ICU_CONFIG_H_

#define ICU_EXTI_CHANNEL	EXTI0


#endif /* ICU_ICU_CONFIG_H_ */
