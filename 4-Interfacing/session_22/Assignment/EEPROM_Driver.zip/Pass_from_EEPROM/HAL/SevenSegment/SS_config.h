/*
 * SS_config.h
 *
 *  Created on: Jul 28, 2024
 *      Author: Mohammed Mansour
 */

#ifndef SEVENSEGMENT_SS_CONFIG_H_
#define SEVENSEGMENT_SS_CONFIG_H_

#define SEVEN_SEGMENT1_PORT		PORTB


#endif /* SEVENSEGMENT_SS_CONFIG_H_ */
