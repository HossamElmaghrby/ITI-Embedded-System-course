/*
 * EEPROM_config.h
 *
 *  Created on: Aug 12, 2024
 *      Author: Elmag
 */

#ifndef EEPROM_EEPROM_CONFIG_H_
#define EEPROM_EEPROM_CONFIG_H_

#define EEPROM_A2_VAL  EEPROM_A2_LOW

#endif /* EEPROM_EEPROM_CONFIG_H_ */
