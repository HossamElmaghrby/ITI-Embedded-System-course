/*
 * Servo_private.h
 *
 *  Created on: Aug 5, 2024
 *      Author: Mohammed Mansour
 */

#ifndef SERVO_SERVO_PRIVATE_H_
#define SERVO_SERVO_PRIVATE_H_

#define SERVO_PERIOD_US		20000

#endif /* SERVO_SERVO_PRIVATE_H_ */
