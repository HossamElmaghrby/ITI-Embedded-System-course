/*
 * LED_config.h
 *
 *  Created on: Jul 25, 2024
 *      Author: Elmag
 */

#ifndef LED_LED_CONFIG_H_
#define LED_LED_CONFIG_H_



#endif /* LED_LED_CONFIG_H_ */
