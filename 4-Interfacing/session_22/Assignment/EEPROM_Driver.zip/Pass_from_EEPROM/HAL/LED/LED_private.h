/*
 * LED_private.h
 *
 *  Created on: Jul 25, 2024
 *      Author: Elmag
 */

#ifndef LED_LED_PRIVATE_H_
#define LED_LED_PRIVATE_H_

#define LED1_PORT  PORTD
#define LED1_PIN   PIN0

#define LED2_PORT PORTD
#define LED2_PIN  PIN1

#define LED3_PORT PORTD
#define LED3_PIN  PIN2

#define LED4_PORT PORTD
#define LED4_PIN  PIN3

#define LED5_PORT PORTD
#define LED5_PIN  PIN4


#endif /* LED_LED_PRIVATE_H_ */
