/*
 * KeyPade_interface.h
 *
 *  Created on: Jul 29, 2024
 *      Author: Elmag
 */

#ifndef KEYPADE_KEYPADE_INTERFACE_H_
#define KEYPADE_KEYPADE_INTERFACE_H_

void Keypad_init();
u8 Keypad_getkey(void);

#endif /* KEYPADE_KEYPADE_INTERFACE_H_ */
