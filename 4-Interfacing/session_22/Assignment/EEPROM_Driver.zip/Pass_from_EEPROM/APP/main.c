/*
 * main.c
 *
 *  Created on: Aug 15, 2024
 *      Author: Hossam Bahaa
 */

#include  "../LIB/STD_Types.h"

#include "../HAL/EEPROM/EEPROM_interface.h"
#include "../HAL/LCD/LCD_interface.h"
#include "../HAL/KeyPade/KeyPade_interface.h"
#include "../HAL/LED/LED_interface.h"
#include "../HAL/Servo/Servo_interface.h"
#include <avr/delay.h>
#define SLAVE1 0x12



int data  = 0;
int main()
{

EEPROM_Init();

EEPROM_SendByte(5 , 0x00);
EEPROM_ReadByte(&data , 0x00);


while(1)
{

}
return 0 ;
}

